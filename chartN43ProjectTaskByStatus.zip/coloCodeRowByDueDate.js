(function () {
    var statusFieldCtx = {};
 
    statusFieldCtx.Templates = {};
    statusFieldCtx.Templates.Fields = {
        "KPI": {"View": StatusIconViewTemplate}
    };
 
    SPClientTemplates.TemplateManager.RegisterTemplateOverrides(statusFieldCtx);
})();
 
function StatusIconViewTemplate(ctx) {
    var _dueDate = new Date(ctx.CurrentItem.DueDate0);
     
    var now = new Date();
    var nowPlus = new Date();
    nowPlus.setDate(now.getDate()+7);
    if (_dueDate == 'undefined' || !_dueDate) {
        return '';
    }
    else if (_dueDate < now) 
    {
        return "<span><font style='color:red'>" + _dueDate.toLocaleDateString() + "</font></span>";
    }
    else if (_dueDate >= now && _dueDate <= nowPlus) 
    {
        return "<span><font style='color:black'>" + _dueDate.toLocaleDateString() + "</font></span>";
    }
    else if (_dueDate > now) 
    {
        return "<span><font style='color:black'>" + _dueDate.toLocaleDateString() + "</font></span>";
    }
}

