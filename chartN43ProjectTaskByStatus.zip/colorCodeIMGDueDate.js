(function () {
    var statusFieldCtx = {};
 
    statusFieldCtx.Templates = {};
    statusFieldCtx.Templates.Fields = {
        "Indicator": {"View": StatusIconViewTemplate}
    };
 
    SPClientTemplates.TemplateManager.RegisterTemplateOverrides(statusFieldCtx);
})();
 
function StatusIconViewTemplate(ctx) {
    var _dueDate = new Date(ctx.CurrentItem.DueDate0);
     
    var now = new Date();
    var nowPlus = new Date();
    nowPlus.setDate(now.getDate()+7);
    if (_dueDate == 'undefined' || !_dueDate) {
        return '';
    }
    else if (_dueDate < now) 
    {
        return "<span><font style='color:red'><img src='https://usff.navy.deps.mil/sites/netwarcom/N4-N7/KM/BenSandBox/SiteAssets/redCircle2.png'/></font></span>";
    }
    else if (_dueDate >= now && _dueDate <= nowPlus) 
    {
        return "<span><font style='color:black'><img src='https://usff.navy.deps.mil/sites/netwarcom/N4-N7/KM/BenSandBox/SiteAssets/yellowCircle4.png'/></font></span>";
    }
    else if (_dueDate > now) 
    {
        return "<span><font style='color:black'><img src='https://usff.navy.deps.mil/sites/netwarcom/N4-N7/KM/BenSandBox/SiteAssets/greenCircle2.png'/></font></span>";
    }
}
