//overrides SP list template
(function () {
    var statusFieldCtx = {};
 
    statusFieldCtx.Templates = {};
    statusFieldCtx.Templates.Fields = {
        "KPI": {"View": StatusIconViewTemplate} //override the Indicator filed view
    };
 
    SPClientTemplates.TemplateManager.RegisterTemplateOverrides(statusFieldCtx); //register
})();
 

//fetch value from duedate column & compare it to today's date 
function StatusIconViewTemplate(ctx) {
    var _dueDate = new Date(ctx.CurrentItem.DueDate);
     
    var now = new Date();
    var nowPlus = new Date();
    nowPlus.setDate(now.getDate()+7);
    if (_dueDate == 'undefined' || !_dueDate) {
        return '';
    }
    else if (_dueDate < now) 
    {
        return "<span><font style='color:red'>" + _dueDate.toLocaleDateString() + "</font></span>";
    }
    else if (_dueDate >= now && _dueDate <= nowPlus) 
    {
        return "<span><font style='color:black'>" + _dueDate.toLocaleDateString() + "</font></span>";  
    }
    else if (_dueDate > now) 
    {
        return "<span><font style='color:black'>" + _dueDate.toLocaleDateString() + "</font></span>";
    }
}

