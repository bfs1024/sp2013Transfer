		<!DOCTYPE html>
2.<html>
3. 
4.<head>
5.    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
6.    <script>
7.        $(document).ready(function() {
8.            $('#btn').click(function() {
9. 
10.                var link = $("<a>");
11.                link.attr("href", "http://www.google.com");
12.                link.attr("title", "Google.com");
13.                link.text("Google");
14.                link.addClass("link");
15. 
16.                $(".box").html(link);
17.            });
18.        });
19.    </script>
20.</head>
21. 
22.<style>
23.    p {
24.        margin: 10px;
25.        font-weight: bold;
26.    }
27.    
28.    .link {
29.        color: red;
30.        font-size: 25px;
31.        font-weight: bold;
32.        text-decoration-style: solid;
33.        margin: 10px;
34.    }
35.</style>
36. 
37.<body>
38.    <h1>Jquery Show Hide </h1>
39.    <div class="box" id="box"></div>
40.    <p><input type="button" id="btn" value="Create Link"></p>
41.</body>
42. 
43.</html>

