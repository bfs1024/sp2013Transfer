$(document).ready(function() {    
    loadItems();    
});    
    
  
function loadItems() {    
    var siteUrl = "https://usff.navy.deps.mil/sites/netwarcom/N4-N7/_api/web/lists/getbytitle('Portal%20Service')/items?$select=Title,Hardware,Comment,Email,Status,V3Comments,DueDate";
   // var oDataUrl = siteUrl;   
    $.ajax({    
        url: siteUrl,    
        type: "GET",    
        dataType: "json",    
        headers: {    
            "accept": "application/json;odata=verbose"    
        },    
        success: mySuccHandler,    
        error: myErrHandler    
    });    
}    
  
function mySuccHandler(data) 
{    
     try
	{    
          
        $('#table_id').DataTable(
		{    
              
            "aaData": data.d.results,    
            "aoColumns": [  
            {    
                "mData": "Title"    
            },   
            {    
                "mData": "Hardware"    
            },   
            {    
                "mData": "Comment"    
            },
			{    
                "mData": "Email"    
            },
            {
            	"mData": "Status"
            },
                        
            {
            	"mData": "V3Comments"

            },
             {
            	"mData": "DueDate"

            }               
            ]    
        });    
    } catch (e) {    
        alert(e.message);    
    }    
}    
    
function myErrHandler(data, errMessage) {    
    alert("Error: " + errMessage);    
}  