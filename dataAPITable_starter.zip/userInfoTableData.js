$(document).ready(function() {    
    loadItems();    
});    
    
  
function loadItems() {    
    var siteUrl = "https://usff.navy.deps.mil/sites/netwarcom/N4-N7/KM/ks/sppj/tb/_api/web/lists/getbytitle('userInfo')/items?$select=Title,Name,Job";
   // var oDataUrl = siteUrl;   
    $.ajax({    
        url: siteUrl,    
        type: "GET",    
        dataType: "json",    
        headers: {    
            "accept": "application/json;odata=verbose"    
        },    
        success: mySuccHandler,    
        error: myErrHandler    
    });    
}    
  
function mySuccHandler(data) 
{    
     try
	{    
          
        $('#table_id').DataTable(
		{    
              
            "aaData": data.d.results,    
            "aoColumns": [  
            {    
                "mData": "Title"    
            },   
            {    
                "mData": "Name"    
            },   
            {    
                "mData": "Job"    
            }
			             
            ]    
        });    
    } catch (e) {    
        alert(e.message);    
    }    
}    
    
function myErrHandler(data, errMessage) {    
    alert("Error: " + errMessage);    
}  