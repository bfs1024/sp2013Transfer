$(document).ready(function() {    
            bindButtonClick();    
}); 


function bindButtonClick() {
    $("#btnSubmit").on("click", function () {
        deleteListItem();
    });
}

function deleteListItem() {
    var id = $("#txtId").val();

    //var siteUrl = _spPageContextInfo.webAbsoluteUrl;
    var fullUrl = "https://usff.navy.deps.mil/sites/netwarcom/N4-N7/KM/ks/sppj/tb/rapic/_api/web/lists/GetByTitle('restcall%20Test')/items(" + id + ")";

    $.ajax({
        url: fullUrl,
        type: "POST",
        headers: {
            "accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val(),
            "X-HTTP-Method": "DELETE",
            "IF-MATCH": "*"
        },
        success: onQuerySucceeded,
        error: onQueryFailed
    });
}

function onQuerySucceeded(sender, args) {
    $("#divResult").html("Item successfully deleted!");
}

function onQueryFailed() {
    alert('Error!');
}