$(document).ready(function() {    
    retrieveListItems();    
}); 

function retrieveListItems() {
    var siteUrl = _spPageContextInfo.webAbsoluteUrl;
    var fullUrl = siteUrl + "/_api/web/lists/GetByTitle('Tasks')/items";

    $.ajax({
        url: fullUrl,
        type: "GET",
        headers: {
            "accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
        },
        success: showAds,
        error: onQueryFailed
    });
}

/*function onQuerySucceeded(data) {
    var listItemInfo = '';
    
    $.each(data.d.results, function (key, value) {
        listItemInfo += '<strong>ID: </strong> ' + value.Id +
            ' <strong>Title:</strong> ' + value.Title +
            '<br />';
    });

    $("#divListItems").html(listItemInfo);
} */

function onQueryFailed(sender, args) {
    alert('Error!');
}

function showAds(data) {
    //
            $.each(data.d.results, function (index, value) {
    //key,value
                //	appending retrieved data to the div
                    $("#ads").append(
                        "<div class='myAds adBox'style='margin:0 auto;'>" +
                        "<div class='adInfo'>" + value.Id +   "<div>"+ value.Title + "</div>" + "<div>" + value.Status + "</div>"                   
                                   
   
                    );
            });
        }