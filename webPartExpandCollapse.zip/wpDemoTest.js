


//make ajax call fetch DataList titile and created date via rest
function myLoadWD(){
    $.ajax({
        url: "https://usff.navy.deps.mil/sites/netwarcom/N4-N7/KM/ks/sppj/wds/_api/web/lists/GetByTitle('DemoList')", //rest api url requesting list properties
        type: "GET", //GET method used to request data
        headers: {
            "accept": "application/json;odata=verbose"  //returns data in JSON format, XML format standard in SP
        },
        success: mySuccWD,
        error: myErrWD
    }).success(function(data){  //passes the data object returned from rest api call 
        $("#testDiv").html(data.d.Title + " : " + data.d.Created);  //query data.d for title and created date of list
});
};


function myLoadWD() {    
    var siteUrl = "https://usff.navy.deps.mil/sites/netwarcom/N4-N7/KM/ks/sppj/wds/_api/web/lists/GetByTitle('DemoList')";
   // var oDataUrl = siteUrl;   
    $.ajax({    
        url: siteUrl,    
        type: "GET",    
        dataType: "json",    
        headers: {    
            "accept": "application/json;odata=verbose"    
        },    
        success: mySuccWD,    
        error: myErrWD    
    });    
}  

function mySuccWD (data) {
    $("#testDiv").html(data.d.Title + " : " + data.d.Created);

};

function myErrWD () {
    console.log("failed");
};
